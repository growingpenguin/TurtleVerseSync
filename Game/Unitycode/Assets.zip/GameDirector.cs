using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class GameDirector : MonoBehaviour
{
    GameObject hpGauge;

    void Start()
    {
        this.hpGauge = GameObject.Find("hpGauge");
    }

    public void DecreaseHp()
    {
        this.hpGauge.GetComponent<Image>().fillAmount -= 0.1f; // Decrease health gauge
        // Assume "ouch" indicates HP decrease from an arrow hit
        SendData("ouch", "/api/collision");
    }

    // Updated to match PlayerController structure with specific endpoints
    private void SendData(string action, string apiEndpoint)
    {
        var data = new
        {
            action = action,
            time = Time.time
        };

        StartCoroutine(PostData("http://localhost:8080" + apiEndpoint, data));
    }

    IEnumerator PostData(string url, object data)
    {
        string json = JsonUtility.ToJson(data);
        byte[] jsonToSend = new System.Text.UTF8Encoding().GetBytes(json);
        UnityWebRequest request = new UnityWebRequest(url, "POST");
        request.uploadHandler = new UploadHandlerRaw(jsonToSend);
        request.downloadHandler = new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Error while sending data: " + request.error);
        }
        else
        {
            Debug.Log("Successfully sent data to " + url + ". Server response: " + request.downloadHandler.text);
        }
    }
}
